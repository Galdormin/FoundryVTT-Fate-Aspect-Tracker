# Patch Notes:

## Version 0.2

* Control button are now hidden in the player view.
* GM can drag'n'drop aspects on the canvas to create a text box.
* Text box from every scene are updated when the aspect is changed.
* Text box are deleted when the aspect is deleted from the tracker.

## Version 0.1

  * GM can create, edit and delete aspect
  * GM can change the number of free invoke without editing the aspect.
  * Add 3 different tags on aspect (situation, boost & resources).
  * Player is updated when GM changes something (through socket).